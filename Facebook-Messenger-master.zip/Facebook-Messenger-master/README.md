![alt text](http://i67.tinypic.com/25rp890.jpg)

<p align="center">
<br>
<b>CSS & HTML template</b> revised version of the Facebook Messenger which I discovered online over at <a href="https://dribbble.com/shots/3407020-Messenger-Redesign">here.</a>
<p align="center">
Code maybe a tad messy! free to use &#128077; <span style="color:#1785F8">v1.0</span>
</p>
  <br>
  
![alt text](http://i66.tinypic.com/9tfxoj.jpg)
  
